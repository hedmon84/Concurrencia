﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SkyTravel.Core.Entities
{
    public class FilterMaster 
    {

        public string place { get; set; }

        public string date { get; set; }

        public string date2 { get; set; }

        public float price { get; set; }

        public int internet { get; set; }






    }
}
