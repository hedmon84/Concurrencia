﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SkyTravel.Core.Enum
{
    public enum ResponseCode
    {
        Success,
        Error,
        NotFound
    }
}
